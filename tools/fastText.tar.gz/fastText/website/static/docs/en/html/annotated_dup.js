var annotated_dup =
[
    [ "fasttext", "namespacefasttext.html", "namespacefasttext" ]
];