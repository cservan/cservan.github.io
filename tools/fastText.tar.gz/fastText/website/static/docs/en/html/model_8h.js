var model_8h =
[
    [ "Node", "structfasttext_1_1Node.html", "structfasttext_1_1Node" ],
    [ "Model", "classfasttext_1_1Model.html", "classfasttext_1_1Model" ],
    [ "LOG_TABLE_SIZE", "model_8h.html#a39f445c336c3e871eccbaa0423b6daef", null ],
    [ "MAX_SIGMOID", "model_8h.html#a526b042c8c04cdd0f0f5c9e097d5ca34", null ],
    [ "SIGMOID_TABLE_SIZE", "model_8h.html#a2e8aaf1ce5284c2017df4d6a3b631532", null ]
];