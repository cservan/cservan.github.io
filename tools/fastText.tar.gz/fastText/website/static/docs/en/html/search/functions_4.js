var searchData=
[
  ['estep',['Estep',['../classfasttext_1_1ProductQuantizer.html#aeba73a087e59f504472063db0a217e84',1,'fasttext::ProductQuantizer']]]
];
