var searchData=
[
  ['args',['Args',['../classfasttext_1_1Args.html',1,'fasttext']]]
];
