var productquantizer_8cc =
[
    [ "distL2", "productquantizer_8cc.html#a4336b1849ad0c1f134ed0ac9842f053c", null ]
];