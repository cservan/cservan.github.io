EMS_DIR=/home/hieu/workspace/github/mosesdecoder/scripts/ems

nice $EMS_DIR/experiment.perl -exec -config=config.hierarchical
#nice $EMS_DIR/experiment.perl -exec -continue=1


