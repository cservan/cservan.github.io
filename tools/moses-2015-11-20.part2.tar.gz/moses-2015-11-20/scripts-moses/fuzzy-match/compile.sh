g++  -I ../../moses/src/ -I ../../ create_xml.cpp Alignments.cpp

